"""Application version metadata."""

APP_VERSION = "0.4.8"
